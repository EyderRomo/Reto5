package com.usa.reto3v2.repository.crudRepository;

import com.usa.reto3v2.entities.Reservation;
import org.springframework.data.repository.CrudRepository;

public interface ReservationCrudRepository extends CrudRepository<Reservation,Integer> {
}
