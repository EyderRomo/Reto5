package com.usa.reto3v2.repository.crudRepository;

import com.usa.reto3v2.entities.Admin;
import org.springframework.data.repository.CrudRepository;

public interface AdminCrudRepository extends CrudRepository<Admin,Integer> {
}
