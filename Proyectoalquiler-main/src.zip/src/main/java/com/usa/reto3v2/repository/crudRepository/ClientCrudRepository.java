package com.usa.reto3v2.repository.crudRepository;

import com.usa.reto3v2.entities.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository<Client, Integer> {
}
