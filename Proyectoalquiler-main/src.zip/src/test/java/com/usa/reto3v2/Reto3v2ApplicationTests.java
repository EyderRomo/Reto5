package com.usa.reto3v2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3v2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
